package com.farmdoc.com.farmdoc;

        import android.content.DialogInterface;
        import android.content.Intent;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.view.View.OnClickListener;
        import android.widget.EditText;


public class LoginReg extends AppCompatActivity {
    Button login, register;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_register);
        register = (Button) findViewById(R.id.btn3);
        register.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(LoginReg.this, Register.class);
                startActivity(myIntent);
            }
        });


    }
}



