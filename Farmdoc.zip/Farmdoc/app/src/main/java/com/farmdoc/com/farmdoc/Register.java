package com.farmdoc.com.farmdoc;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Register extends AppCompatActivity {

    EditText et1,et2;
    Button btn;
    Button botton4,botton5;
    String method,user,pwd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);
        et1=(EditText)findViewById(R.id.username);
        et2=(EditText)findViewById(R.id.password);

        btn=(Button)findViewById(R.id.reg);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                method="signup";
                user=et1.getText().toString();
                pwd=et2.getText().toString();
                BG_TASK bg_task=new BG_TASK(Register.this);
                bg_task.execute(method,user,pwd);
                botton4 = (Button) findViewById(R.id.reg);
                botton4.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent myIntent = new Intent(Register.this, com.farmdoc.com.farmdoc.Gps.class);
                        startActivity(myIntent);
                    }
            }
        });

    }
}
