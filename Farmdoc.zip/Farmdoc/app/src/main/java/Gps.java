/**
 * Created by naveen on 19-09-2017.
 */

package com.farmdoc.com.farmdoc;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.widget.EditText;


public class Gps extends AppCompatActivity {
    Button botton4,botton5;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gps);
        botton4 = (Button) findViewById(R.id.reg);
        botton4.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(Register.this,Gps.class);
                startActivity(myIntent);
            }
        });

    }
}


